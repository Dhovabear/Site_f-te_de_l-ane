<aside>
	<nav>
		<h3>Accueil</h3>
		<ul>
			<li><a href="accueil.php#Presentation">Présentation</a></li>
			<li><a href="accueil.php#Photos">Photos</a></li>
		</ul>
		<h3>Actualités</h3>
		<ul>
			<li><a href="actualitées.php#cetAnne">La fête revient cette année !</a></li>
			<li><a href="actualitées.php#interview">Interview</a></li>
		</ul>
		<h3>Exposants</h3>
		<ul>
			<li><a href="intervenants.php">Liste des exposants</a></li>
		</ul>
		<h3>Contact</h3>
		<ul>
			<li><a href="contact.php">Organisateurs</a></li>
			<li><a href="contact.php#contacter">Nous contacter</a></li>
		</ul>

	</nav>
</aside>