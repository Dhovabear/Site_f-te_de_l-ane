<footer>
	<p> Site réalisé dans le cadre du projet Tuteuré de S1 a l'universitée de Belfort-Monbéliard département informatique</p>
</footer>