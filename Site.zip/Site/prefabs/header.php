
<header>
	<img src= "../Ressources/Images/Logo_Ane.png" alt="logo de la fete de l'âne" style  = "height: 160px ; width: 140px; margin-left: 100px ; float: left;">
	<div style = "display: inline-block;">
		<h1 style = "margin-bottom: 10px;">La fête de l'âne</h1>
		<h3 style = "margin-top: 10px;">de Suarce</h3>
	</div>
	<img src= "../Ressources/Images/Logo_Ane.png" alt="logo de la fete de l'âne" style  = "height: 160px ; width: 140px; margin-right: 100px; float : right">
	<div style = "clear: both;">
</header>